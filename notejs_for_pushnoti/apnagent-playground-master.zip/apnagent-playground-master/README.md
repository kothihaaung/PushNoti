# apnagent-playground

> Sample application for article: "Delivering iOS Push Notifications with Node.js"

#### Resources

**article**

- [Delivering iOS Push Notifications with Node.js](https://blog.engineyard.com/2013/developing-ios-push-notifications-nodejs)

**apnagent**

- npm: [apnagent](https://npmjs.org/package/apnagent)
- Documentation: [apnagent.qualiancy.com](http://apnagent.qualiancy.com)
- GitHub: [qualiancy / apnagent](https://github.com/qualiancy/apnagent) [[issues](https://github.com/qualiancy/apnagent/issues)]

**apnagent-ios**

- GitHub: [logicalparadox / apnagent-ios](https://github.com/logicalparadox/apnagent-ios) [[issues](https://github.com/logicalparadox/apnagent-ios/issues)]
