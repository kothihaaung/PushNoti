module.exports = "YOUR_DEVICE_TOKEN";
